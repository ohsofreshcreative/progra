# Hide and Seek

Wtyczka wyświetla nazwy bloków ACF (np. `acf/hero`) w lewym górnym rogu ich pierwszego elementu HTML. Etykiety widzą tylko zalogowani użytkownicy z uprawnieniem `manage_options`, na froncie strony.

## Instalacja

1. Skopiuj cały folder `hide-and-seek` do `wp-content/plugins/` albo zainstaluj archiwum `hide-and-seek.zip` przez panel WordPressa.
2. Aktywuj wtyczkę **Hide and Seek**.
3. W **Ustawienia → Hide and Seek** zaznacz **Pokaż etykiety bloków na stronie** i zapisz.

Wymagania: WordPress 6.2+, PHP 8.0+. Wtyczka korzysta z natywnego panelu ustawień WordPressa. Nie wymaga Sage, ACF Composer ani builda assetów. Do wyświetlania bloków ACF potrzebna jest ich dotychczasowa implementacja.

Wtyczka ma własną opcję, domyślnie wyłączoną; nie zmienia ustawień ACF. Mechanizm nie obsługuje bloków innych niż `acf/*` ani bloków bez elementu HTML. Cache strony powinien pomijać zalogowanych użytkowników, aby nie udostępniać ich wersji HTML odwiedzającym.

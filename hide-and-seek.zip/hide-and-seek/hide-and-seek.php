<?php
/**
 * Plugin Name: Hide and Seek
 * Description: Wyświetla administratorom nazwy bloków ACF na stronie.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 */

namespace HideAndSeek;

defined('ABSPATH') || exit;

function labels_enabled(): bool
{
	return ! is_admin() && current_user_can('manage_options') && (bool) get_option('hide_and_seek_show_block_labels', false);
}

add_action('admin_menu', function () {
	add_options_page('Hide and Seek', 'Hide and Seek', 'manage_options', 'hide-and-seek', __NAMESPACE__ . '\\settings_page');
});

add_action('admin_init', function () {
	register_setting('hide_and_seek', 'hide_and_seek_show_block_labels', [
		'type' => 'boolean',
		'default' => false,
		'sanitize_callback' => function ($value) { return (bool) $value; },
	]);
});

function settings_page(): void
{
	if (! current_user_can('manage_options')) {
		return;
	}
	?>
	<div class="wrap">
		<h1>Hide and Seek</h1>
		<?php settings_errors(); ?>
		<form action="options.php" method="post">
			<?php settings_fields('hide_and_seek'); ?>
			<input type="hidden" name="hide_and_seek_show_block_labels" value="0">
			<p>
				<label for="hide-and-seek-show-block-labels">
					<input type="checkbox" id="hide-and-seek-show-block-labels" name="hide_and_seek_show_block_labels" value="1" <?php checked((bool) get_option('hide_and_seek_show_block_labels', false)); ?>>
					Pokaż etykiety bloków na stronie
				</label>
			</p>
			<p class="description">Etykiety bloków ACF są widoczne wyłącznie na stronie dla zalogowanych użytkowników z uprawnieniem zarządzania opcjami (administratorów).</p>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

add_action('wp_enqueue_scripts', function () {
	if (labels_enabled()) {
		wp_enqueue_style('hide-and-seek', plugins_url('hide-and-seek.css', __FILE__), [], '1.0.0');
	}
});

add_filter('render_block', function ($block_content, $block) {
	if (! str_starts_with($block['blockName'] ?? '', 'acf/') || ! labels_enabled() || ! class_exists('WP_HTML_Tag_Processor')) {
		return $block_content;
	}

	$processor = new \WP_HTML_Tag_Processor($block_content);
	if (! $processor->next_tag()) {
		return $block_content;
	}

	$processor->add_class('has-acf-block-label');
	$processor->set_attribute('data-acf-block-label', $block['blockName']);

	return $processor->get_updated_html();
}, 10, 2);
